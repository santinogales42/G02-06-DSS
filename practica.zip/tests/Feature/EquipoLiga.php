<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;
use App\Models\Equipo;
use App\Models\Liga;
use Illuminate\Support\Facades\DB;
class EquipoLiga extends TestCase
{
    use RefreshDatabase;
    /**
     * A basic feature test example.
     *
     * @return void
     */
    public function test_example()
    {
        $response = $this->get('/');

        $response->assertStatus(200);
    }
    /** @test */

    public function equipo_pertenece_a_una_liga()
    {
        $liga = Liga::create(['nombre' => 'La Liga', 'pais' => 'España', 'temporada' => '2024']);
        $equipo = Equipo::create(['nombre' => 'Equipo B', 'liga_id' => $liga->id]);

        $this->assertTrue($equipo->liga->is($liga));
    }
    
    /** @test */
    public function liga_tiene_multiples_equipos()
    {
        $liga = Liga::create(['nombre' => 'La Liga', 'pais' => 'España', 'temporada' => '2024']);
        $equipo1 = Equipo::create(['nombre' => 'Equipo E', 'liga_id' => $liga->id]);
        $equipo2 = Equipo::create(['nombre' => 'Equipo F', 'liga_id' => $liga->id]);

        $this->assertCount(2, $liga->equipos);
    }

    

}