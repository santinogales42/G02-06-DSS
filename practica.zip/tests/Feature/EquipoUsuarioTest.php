<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;
use App\Models\Equipo;
use App\Models\Usuario;
use Illuminate\Support\Facades\DB;
class EquipoUsuario extends TestCase
{
    use RefreshDatabase;
    /**
     * A basic feature test example.
     *
     * @return void
     */
    public function test_example()
    {
        $response = $this->get('/');

        $response->assertStatus(200);
    }

    /** @test */
    public function test_usuario_puede_pertenecer_a_multiples_equipos()
    {
        $usuario = Usuario::create(['nombre' => 'Usuario 1']);
        $equipo1 = Equipo::create(['nombre' => 'Equipo I']);
        $equipo2 = Equipo::create(['nombre' => 'Equipo J']);

        $usuario->equipos()->attach($equipo1->id);
        $usuario->equipos()->attach($equipo2->id);

        $this->assertCount(2, $usuario->equipos);
    }

    /** @test */
    public function test_se_puede_desasociar_equipos_de_un_usuario()
    {
        $usuario = Usuario::create(['nombre' => 'Usuario 1']);
        $equipo1 = Equipo::create(['nombre' => 'Equipo 1']);
        $equipo2 = Equipo::create(['nombre' => 'Equipo 2']);

        // Asociar los equipos al usuario
        $usuario->equipos()->attach($equipo1->id);
        $usuario->equipos()->attach($equipo2->id);

        // Desasociar un equipo
        $usuario->equipos()->detach($equipo1->id);

        // Verificar que solo queda un equipo asociado
        $this->assertCount(1, $usuario->equipos()->get());

        // Verificar que el equipo desasociado ya no está asociado
        $this->assertFalse($usuario->equipos()->where('id', $equipo1->id)->exists());
    }
}
