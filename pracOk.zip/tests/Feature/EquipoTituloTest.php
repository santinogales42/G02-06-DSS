<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;
use App\Models\Equipo;
use App\Models\Titulo;

class EquipoTituloTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function un_equipo_puede_tener_multiples_titulos()
    {
        $equipo = Equipo::create(['nombre' => 'Equipo Prueba']);
        $titulo1 = Titulo::create(['nombre' => 'Titulo 1', 'temporada' => 2021]);
        $titulo2 = Titulo::create(['nombre' => 'Titulo 2', 'temporada' => 2022]);

        $equipo->titulos()->attach($titulo1->id);
        $equipo->titulos()->attach($titulo2->id);

        $this->assertEquals(2, $equipo->titulos()->count());
    }

    /** @test */
    public function un_titulo_puede_pertenecer_a_multiples_equipos()
    {
        $equipo1 = Equipo::create(['nombre' => 'Equipo 1']);
        $equipo2 = Equipo::create(['nombre' => 'Equipo 2']);
        $titulo = Titulo::create(['nombre' => 'Titulo Compartido', 'temporada' => 2023]);

        $titulo->equipos()->attach($equipo1->id);
        $titulo->equipos()->attach($equipo2->id);

        $this->assertEquals(2, $titulo->equipos()->count());
    }
}

