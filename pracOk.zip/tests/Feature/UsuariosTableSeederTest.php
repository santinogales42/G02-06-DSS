<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use App\Models\Usuario;

class UsuariosTableSeederTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function it_seeds_the_usuarios_table()
    {
        // Simula la ejecución del seeder
        $this->artisan('db:seed', ['--class' => 'Database\\Seeders\\UsuariosTableSeeder']);
        
        // Verifica que el usuario se haya insertado en la base de datos
        $this->assertDatabaseHas('usuarios', [
            'nombre' => 'JuaPérez',
            'correo' => 'jez@example.com',
            // No verificamos la contraseña aquí porque está encriptada
        ]);
        
        // Opcionalmente, verifica que la contraseña es correcta
        $user = Usuario::where('correo', 'jez@example.com')->first();
        $this->assertTrue(\Hash::check('password', $user->contraseña));
    }
}

